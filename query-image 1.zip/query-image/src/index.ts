import { AzureChatOpenAI } from '@langchain/openai';

import { ChatPromptTemplate } from '@langchain/core/prompts';

import { readFile } from 'node:fs/promises';

import 'dotenv/config';


const AZURE_OPENAI_API_INSTANCE_NAME="<>"
const AZURE_OPENAI_API_KEY="<>"
const AZURE_OPENAI_API_DEPLOYMENT_NAME="gpt-4"
const AZURE_OPENAI_API_VERSION="2024-08-01-preview"

// Model LLM
const llm = new AzureChatOpenAI({
  temperature: 0.9,
  azureOpenAIApiKey: AZURE_OPENAI_API_KEY,
  azureOpenAIApiInstanceName: AZURE_OPENAI_API_INSTANCE_NAME,
  azureOpenAIApiDeploymentName: AZURE_OPENAI_API_DEPLOYMENT_NAME,
  azureOpenAIApiVersion: AZURE_OPENAI_API_VERSION,
});


const encodeImage = async (imagePath: any) => {
  const imageData = await readFile(imagePath);
  return imageData.toString('base64');
}

const image = await encodeImage('./image.jpg');
console.log(image.length)


const prompt = ChatPromptTemplate.fromMessages([
  ['system', 'You are a helpful assistant that can describe images in detail.'],
  ['human',
    [
      { type: 'text', text: '{input}' },
      {
        type: 'image_url',
        image_url: {
          url: `data:image/jpeg;base64,${image}`,
          detail: 'low',
        },
      },
    ],
  ],
]);

const chain = prompt.pipe(llm);
const response = await chain.invoke({"input": "What do you see on this image?"})

// orange tabby cat sitting against a white background

console.log(response.content);
