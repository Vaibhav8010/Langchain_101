import { AzureChatOpenAI,AzureOpenAIEmbeddings } from "@langchain/openai";


import "cheerio";
import { CheerioWebBaseLoader } from "@langchain/community/document_loaders/web/cheerio";
import { RecursiveCharacterTextSplitter } from "langchain/text_splitter";
import { MemoryVectorStore } from "langchain/vectorstores/memory";
import { pull } from "langchain/hub";
import { ChatPromptTemplate } from "@langchain/core/prompts";
import { StringOutputParser } from "@langchain/core/output_parsers";
import { createStuffDocumentsChain } from "langchain/chains/combine_documents";


const AZURE_OPENAI_API_INSTANCE_NAME="<>"
const AZURE_OPENAI_API_DEPLOYMENT_NAME="gpt-4o-mini"
const AZURE_OPENAI_API_KEY="<>"
const AZURE_OPENAI_API_VERSION="2024-08-01-preview"

// Model LLM
const llm = new AzureChatOpenAI({
  temperature: 0.9,
  azureOpenAIApiKey: AZURE_OPENAI_API_KEY,
  azureOpenAIApiInstanceName: AZURE_OPENAI_API_INSTANCE_NAME,
  azureOpenAIApiDeploymentName: AZURE_OPENAI_API_DEPLOYMENT_NAME,
  azureOpenAIApiVersion: AZURE_OPENAI_API_VERSION,
});

// Loader Docs
const loader = new CheerioWebBaseLoader(
  "https://lilianweng.github.io/posts/2023-06-23-agent/"
);

const docs = await loader.load();

const EMBED_AZURE_OPENAI_API_INSTANCE_NAME="<>"
const EMBED_AZURE_OPENAI_API_DEPLOYMENT_NAME="text-embedding-3-small"
const EMBED_AZURE_OPENAI_API_KEY="<>"
const EMBED_AZURE_OPENAI_API_VERSION="2023-05-15"

// Embedding Model
const embeddingsModel = new AzureOpenAIEmbeddings({
  azureOpenAIApiKey: EMBED_AZURE_OPENAI_API_KEY,
  azureOpenAIApiInstanceName: EMBED_AZURE_OPENAI_API_INSTANCE_NAME,
  azureOpenAIApiEmbeddingsDeploymentName: EMBED_AZURE_OPENAI_API_DEPLOYMENT_NAME,
  azureOpenAIApiVersion: EMBED_AZURE_OPENAI_API_VERSION, 
  maxRetries: 1,
});

// Splitter
const textSplitter = new RecursiveCharacterTextSplitter({
  chunkSize: 1000,
  chunkOverlap: 200,
});
const splits = await textSplitter.splitDocuments(docs);

// In Memory Vector Store
const vectorStore = await MemoryVectorStore.fromDocuments(
  splits,
  embeddingsModel  
);

// Retrieve and generate using the relevant snippets of the blog.
const retriever = vectorStore.asRetriever();

// Prompt
const prompt = await pull<ChatPromptTemplate>("rlm/rag-prompt");

// RAG Chain
const ragChain = await createStuffDocumentsChain({
  llm,
  prompt,
  outputParser: new StringOutputParser(),
});

// Retriever Query
const retrievedDocs = await retriever.invoke("what is task decomposition");

// Results
const res = await ragChain.invoke({
  question: "What is task decomposition?",
  context: retrievedDocs,
});

console.log(res);