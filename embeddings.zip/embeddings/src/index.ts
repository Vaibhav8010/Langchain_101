// https://js.langchain.com/assets/images/embeddings_concept-975a9aaba52de05b457a1aeff9a7393a.png
// https://js.langchain.com/docs/concepts/embedding_models/
// (1) Embed text as a vector: Embeddings transform text into a numerical vector representation.
// (2) Measure similarity: Embedding vectors can be comparing using simple mathematical operations.

import { AzureOpenAIEmbeddings } from "@langchain/openai";

const AZURE_OPENAI_API_INSTANCE_NAME="<>"
const AZURE_OPENAI_API_DEPLOYMENT_NAME="text-embedding-3-small"
const AZURE_OPENAI_API_KEY="<>"
const AZURE_OPENAI_API_VERSION="2023-05-15"

const embeddingsModel = new AzureOpenAIEmbeddings({
  azureOpenAIApiKey: AZURE_OPENAI_API_KEY,
  azureOpenAIApiInstanceName: AZURE_OPENAI_API_INSTANCE_NAME,
  azureOpenAIApiEmbeddingsDeploymentName: AZURE_OPENAI_API_DEPLOYMENT_NAME,
  azureOpenAIApiVersion: AZURE_OPENAI_API_VERSION, 
  maxRetries: 1,
});

const embeddings = await embeddingsModel.embedDocuments([
  "Hi there!",
  "Oh, life!",
  "What's your name?",
  "My friends call me World",
  "Hello World!",
]);

// console.log(`(${embeddings.length}, ${embeddings[0].values()})`);

//embeddings[0].values();
// To do
//for ( item in embeddings[0].values)
//  console.log()

const queryEmbedding = await embeddingsModel.embedQuery(
  "What is the meaning of life?"
);

function cosineSimilarity(vec1: number[], vec2: number[]): number {
  const dotProduct = vec1.reduce((sum, val, i) => sum + val * vec2[i], 0);
  const norm1 = Math.sqrt(vec1.reduce((sum, val) => sum + val * val, 0));
  const norm2 = Math.sqrt(vec2.reduce((sum, val) => sum + val * val, 0));
  return dotProduct / (norm1 * norm2);
}


const similarity1 = cosineSimilarity(queryEmbedding, embeddings[0]);
console.log("Cosine Similarity1:", similarity1);

const similarity2 = cosineSimilarity(queryEmbedding, embeddings[1]);
console.log("Cosine Similarity2:", similarity2);

