// https://js.langchain.com/docs/tutorials/summarization
import { AzureChatOpenAI } from "@langchain/openai";
import { loadSummarizationChain } from "langchain/chains";
import { SearchApiLoader } from "@langchain/community/document_loaders/web/searchapi";
import { TokenTextSplitter } from "@langchain/textsplitters";
import { PromptTemplate } from "@langchain/core/prompts";


const AZURE_OPENAI_API_INSTANCE_NAME="<>"
const AZURE_OPENAI_API_DEPLOYMENT_NAME="gpt-4o-mini"
const AZURE_OPENAI_API_KEY="<>"
const AZURE_OPENAI_API_VERSION="2024-08-01-preview"


const llmSummary = new AzureChatOpenAI({
    temperature: 0.9,
    azureOpenAIApiKey: AZURE_OPENAI_API_KEY,
    azureOpenAIApiInstanceName: AZURE_OPENAI_API_INSTANCE_NAME,
    azureOpenAIApiDeploymentName: AZURE_OPENAI_API_DEPLOYMENT_NAME,
    azureOpenAIApiVersion: AZURE_OPENAI_API_VERSION,
  });

const loader = new SearchApiLoader({
    apiKey: "<>",
    engine: "youtube_transcripts",
    video_id: "WTOm65IZneg",
  });
  
  const docs = await loader.load();

//  console.log(docs.length);


  
  const splitter = new TokenTextSplitter({
    chunkSize: 10000,
    chunkOverlap: 250,
  });
  
  const docsSummary = await splitter.splitDocuments(docs);
  
  
  const summaryTemplate = `
  You are an expert in summarizing YouTube videos.
  Your goal is to create a summary of a podcast.
  Below you find the transcript of a podcast:
  --------
  {text}
  --------
  
  The transcript of the podcast will also be used as the basis for a question and answer bot.
  Provide some examples questions and answers that could be asked about the podcast. 
  Make these questions very specific.
  
  Total output will be a summary of the video and a list of example questions the user could ask of the video.
  
  SUMMARY AND QUESTIONS:
  `;
  
  const SUMMARY_PROMPT = PromptTemplate.fromTemplate(summaryTemplate);
  
  const summaryRefineTemplate = `
  You are an expert in summarizing YouTube videos.
  Your goal is to create a summary of a podcast.
  We have provided an existing summary up to a certain point: {existing_answer}
  
  Below you find the transcript of a podcast:
  --------
  {text}
  --------
  
  Given the new context, refine the summary and example questions.
  The transcript of the podcast will also be used as the basis for a question and answer bot.
  Provide some examples questions and answers that could be asked about the podcast. Make
  these questions very specific.
  If the context isn't useful, return the original summary and questions.
  Total output will be a summary of the video and a list of example questions the user could ask of the video.
  
  SUMMARY AND QUESTIONS:
  `;
  
  const SUMMARY_REFINE_PROMPT = PromptTemplate.fromTemplate(
    summaryRefineTemplate
  );
  
  const summarizeChain = loadSummarizationChain(llmSummary, {
    type: "refine",
    verbose: true,
    questionPrompt: SUMMARY_PROMPT,
    refinePrompt: SUMMARY_REFINE_PROMPT,
  });
  
  const summary = await summarizeChain.run(docsSummary);
  
  console.log(summary);
  
