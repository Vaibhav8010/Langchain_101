import { SqlDatabase } from "langchain/sql_db";
import { DataSource } from "typeorm";
// import {ChatOllama} from '@langchain/ollama';
import { AzureChatOpenAI } from "@langchain/openai";
import { createSqlQueryChain } from "langchain/chains/sql_db";
import { QuerySqlTool } from "langchain/tools/sql";

const datasource = new DataSource({
  type: "sqlite",
  database: "./db/Chinook_Sqlite.sqlite",
});

const db = await SqlDatabase.fromDataSourceParams({
  appDataSource: datasource,
});

//console.log(db.allTables.map((t) => t.tableName));

/*
const llm = new ChatOllama({
  model: "llama2",
  temperature: 0,
  maxRetries: 2,
  // other params...
});
*/


const AZURE_OPENAI_API_INSTANCE_NAME="<>"
const AZURE_OPENAI_API_DEPLOYMENT_NAME="gpt-4"
const AZURE_OPENAI_API_KEY="<>"
const AZURE_OPENAI_API_VERSION="2024-08-01-preview"

const llm = new AzureChatOpenAI({ 
  azureOpenAIApiKey: AZURE_OPENAI_API_KEY,
  azureOpenAIApiInstanceName: AZURE_OPENAI_API_INSTANCE_NAME,
  azureOpenAIApiDeploymentName: AZURE_OPENAI_API_DEPLOYMENT_NAME,
  azureOpenAIApiVersion: AZURE_OPENAI_API_VERSION,
  temperature: 0 });


/* V1 
// SQL Chain
const chain = await createSqlQueryChain({
  llm,
  db,
  dialect: "sqlite",
});

const response = await chain.invoke({
  question: "How many employees are there?",
});

//console.log("response", response);


/**
response SELECT COUNT(*) FROM "Employee"
SELECT COUNT(*) AS EmployeeCount FROM "Employee"
 */

// console.log("db run result", await db.run(response));

/*
db run result [{"COUNT(*)":8}]
 */


// V2

const executeQuery = new QuerySqlTool(db);

const writeQuery = await createSqlQueryChain({
  llm,
  db,
  dialect: "sqlite",
});

const chain = writeQuery.pipe(executeQuery);

console.log(await chain.invoke({ question: "How many artists are there" }));

