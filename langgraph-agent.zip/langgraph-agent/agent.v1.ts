// Optional, add tracing in LangSmith
// process.env.LANGCHAIN_API_KEY = "ls__...";
// process.env.LANGCHAIN_CALLBACKS_BACKGROUND = "true";
// process.env.LANGCHAIN_TRACING_V2 = "true";
// process.env.LANGCHAIN_PROJECT = "Quickstart: LangGraphJS";

// agent.ts

// npx tsx agent.v1.ts 
// IMPORTANT - Add your API keys here. Be careful not to publish them.


const TAVILY_API_KEY = "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"; 

const AZURE_OPENAI_API_INSTANCE_NAME="<>"
const AZURE_OPENAI_API_DEPLOYMENT_NAME="gpt-4"
const AZURE_OPENAI_API_KEY="<>"
const AZURE_OPENAI_API_VERSION="2024-08-01-preview"

import { TavilySearchResults } from "@langchain/community/tools/tavily_search";
import { AzureChatOpenAI } from "@langchain/openai";
import { MemorySaver } from "@langchain/langgraph";
import { HumanMessage } from "@langchain/core/messages";
import { createReactAgent } from "@langchain/langgraph/prebuilt";

// Define the tools for the agent to use
const agentTools = [new TavilySearchResults({ apiKey: TAVILY_API_KEY, maxResults: 3 })];
const agentModel =  new AzureChatOpenAI({
    temperature: 0.9,
    azureOpenAIApiKey: AZURE_OPENAI_API_KEY,
    azureOpenAIApiInstanceName: AZURE_OPENAI_API_INSTANCE_NAME,
    azureOpenAIApiDeploymentName: AZURE_OPENAI_API_DEPLOYMENT_NAME,
    azureOpenAIApiVersion: AZURE_OPENAI_API_VERSION,
  });

// Initialize memory to persist state between graph runs
const agentCheckpointer = new MemorySaver();
const agent = createReactAgent({
  llm: agentModel,
  tools: agentTools,
  checkpointSaver: agentCheckpointer,
});

// Now it's time to use!
const agentFinalState = await agent.invoke(
  { messages: [new HumanMessage("what is the current weather in sf")] },
  { configurable: { thread_id: "42" } },
);

console.log(
  agentFinalState.messages[agentFinalState.messages.length - 1].content,
);

const agentNextState = await agent.invoke(
  { messages: [new HumanMessage("what about ny")] },
  { configurable: { thread_id: "42" } },
);

console.log(
  agentNextState.messages[agentNextState.messages.length - 1].content,
);