// https://js.langchain.com/docs/tutorials/graph

import "neo4j-driver";
import { Neo4jGraph } from "@langchain/community/graphs/neo4j_graph";
import { GraphCypherQAChain } from "langchain/chains/graph_qa/cypher";
import { AzureChatOpenAI } from "@langchain/openai";

const NEO4J_URI="neo4j+s://ba5e7920.databases...."
const NEO4J_USERNAME="neo4j"
const NEO4J_PASSWORD="<>"


const url = NEO4J_URI;
const username = NEO4J_USERNAME;
const password = NEO4J_PASSWORD;
const graph = await Neo4jGraph.initialize({ url, username, password });

// Import movie information
/*
const moviesQuery = `LOAD CSV WITH HEADERS FROM 
'https://raw.githubusercontent.com/tomasonjo/blog-datasets/main/movies/movies_small.csv'
AS row
MERGE (m:Movie {id:row.movieId})
SET m.released = date(row.released),
    m.title = row.title,
    m.imdbRating = toFloat(row.imdbRating)
FOREACH (director in split(row.director, '|') | 
    MERGE (p:Person {name:trim(director)})
    MERGE (p)-[:DIRECTED]->(m))
FOREACH (actor in split(row.actors, '|') | 
    MERGE (p:Person {name:trim(actor)})
    MERGE (p)-[:ACTED_IN]->(m))
FOREACH (genre in split(row.genres, '|') | 
    MERGE (g:Genre {name:trim(genre)})
    MERGE (m)-[:IN_GENRE]->(g))`;

await graph.query(moviesQuery);
*/

await graph.refreshSchema();

// console.log(graph.getSchema());

const AZURE_OPENAI_API_INSTANCE_NAME="<>"
const AZURE_OPENAI_API_DEPLOYMENT_NAME="gpt-4o-mini"
const AZURE_OPENAI_API_KEY="<>"
const AZURE_OPENAI_API_VERSION="2024-08-01-preview"

// Model LLM
const llm = new AzureChatOpenAI({
  temperature: 0.9,
  azureOpenAIApiKey: AZURE_OPENAI_API_KEY,
  azureOpenAIApiInstanceName: AZURE_OPENAI_API_INSTANCE_NAME,
  azureOpenAIApiDeploymentName: AZURE_OPENAI_API_DEPLOYMENT_NAME,
  azureOpenAIApiVersion: AZURE_OPENAI_API_VERSION,
});


const chain = GraphCypherQAChain.fromLLM({
  llm,
  graph,
});
const response = await chain.invoke({
    query: "Who directed GoldenEye?",
    //query: "What was the cast of the Casino?",
});

console.log(response);