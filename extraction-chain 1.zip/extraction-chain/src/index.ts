// https://js.langchain.com/docs/tutorials/extraction

import { z } from "zod";

import { AzureChatOpenAI } from "@langchain/openai";
import { ChatPromptTemplate } from "@langchain/core/prompts";

const personSchema = z.object({
  name: z.string().nullish().describe("The name of the person"),
  hair_color: z
    .string()
    .nullish()
    .describe("The color of the person's hair if known"),
  height_in_meters: z.string().nullish().describe("Height measured in meters"),
});

// Define a custom prompt to provide instructions and any additional context.
// 1) You can add examples into the prompt template to improve extraction quality
// 2) Introduce additional parameters to take context into account (e.g., include metadata
//    about the document from which the text was extracted.)
const prompt = ChatPromptTemplate.fromMessages([
    [
      "system",
      `You are an expert extraction algorithm.
  Only extract relevant information from the text.
  If you do not know the value of an attribute asked to extract,
  return null for the attribute's value.`,
    ],
    // Please see the how-to about improving performance with
    // reference examples.
    // ["placeholder", "{examples}"],
    ["human", "{text}"],
  ]);

    const AZURE_OPENAI_API_INSTANCE_NAME="<>"
    const AZURE_OPENAI_API_DEPLOYMENT_NAME="gpt-4o-mini"
    const AZURE_OPENAI_API_KEY="<>"
    const AZURE_OPENAI_API_VERSION="2024-08-01-preview"

// Model LLM
const llm = new AzureChatOpenAI({
  temperature: 0.9,
  azureOpenAIApiKey: AZURE_OPENAI_API_KEY,
  azureOpenAIApiInstanceName: AZURE_OPENAI_API_INSTANCE_NAME,
  azureOpenAIApiDeploymentName: AZURE_OPENAI_API_DEPLOYMENT_NAME,
  azureOpenAIApiVersion: AZURE_OPENAI_API_VERSION,
});

  const runnable = prompt.pipe(llm.withStructuredOutput(personSchema));

    const text = "Alan Smith is 6 feet tall and has blond hair.";
    const res = await runnable.invoke({ text });

    console.log(res)