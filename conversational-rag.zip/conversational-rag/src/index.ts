/* MASTER VERSION
import { AzureChatOpenAI,AzureOpenAIEmbeddings } from "@langchain/openai";
import "cheerio";
import { CheerioWebBaseLoader } from "@langchain/community/document_loaders/web/cheerio";
import { RecursiveCharacterTextSplitter } from "langchain/text_splitter";
import { MemoryVectorStore } from "langchain/vectorstores/memory";
import { pull } from "langchain/hub";
import { ChatPromptTemplate } from "@langchain/core/prompts";
import { StringOutputParser } from "@langchain/core/output_parsers";
import { createRetrievalChain } from "langchain/chains/retrieval";
import { createStuffDocumentsChain } from "langchain/chains/combine_documents";

import { createHistoryAwareRetriever } from "langchain/chains/history_aware_retriever";
import { MessagesPlaceholder } from "@langchain/core/prompts";
import { BaseMessage, HumanMessage, AIMessage } from "@langchain/core/messages";

import { RunnableWithMessageHistory } from "@langchain/core/runnables";
import { ChatMessageHistory } from "langchain/stores/message/in_memory";

import { createRetrieverTool } from "langchain/tools/retriever";

import { createReactAgent } from "@langchain/langgraph/prebuilt";
import { MemorySaver } from "@langchain/langgraph";

const AZURE_OPENAI_API_INSTANCE_NAME="<>"
const AZURE_OPENAI_API_DEPLOYMENT_NAME="gpt-4o-mini"
const AZURE_OPENAI_API_KEY="<>"
const AZURE_OPENAI_API_VERSION="2024-08-01-preview"

// Model LLM
const llm = new AzureChatOpenAI({
  temperature: 0.9,
  azureOpenAIApiKey: AZURE_OPENAI_API_KEY,
  azureOpenAIApiInstanceName: AZURE_OPENAI_API_INSTANCE_NAME,
  azureOpenAIApiDeploymentName: AZURE_OPENAI_API_DEPLOYMENT_NAME,
  azureOpenAIApiVersion: AZURE_OPENAI_API_VERSION,
});

const EMBED_AZURE_OPENAI_API_INSTANCE_NAME="<>"
const EMBED_AZURE_OPENAI_API_DEPLOYMENT_NAME="text-embedding-3-small"
const EMBED_AZURE_OPENAI_API_KEY="<>"
const EMBED_AZURE_OPENAI_API_VERSION="2023-05-15"

// Embedding Model
const embeddingsModel = new AzureOpenAIEmbeddings({
  azureOpenAIApiKey: EMBED_AZURE_OPENAI_API_KEY,
  azureOpenAIApiInstanceName: EMBED_AZURE_OPENAI_API_INSTANCE_NAME,
  azureOpenAIApiEmbeddingsDeploymentName: EMBED_AZURE_OPENAI_API_DEPLOYMENT_NAME,
  azureOpenAIApiVersion: EMBED_AZURE_OPENAI_API_VERSION, 
  maxRetries: 1,
});

// 1. Load, chunk and index the contents of the blog to create a retriever.
const loader = new CheerioWebBaseLoader(
  "https://lilianweng.github.io/posts/2023-06-23-agent/",
  {
    selector: ".post-content, .post-title, .post-header",
  }
);
const docs = await loader.load();

const textSplitter = new RecursiveCharacterTextSplitter({
  chunkSize: 1000,
  chunkOverlap: 200,
});
const splits = await textSplitter.splitDocuments(docs);
const vectorstore = await MemoryVectorStore.fromDocuments(
  splits,
  embeddingsModel
);

const retriever = vectorstore.asRetriever();

// 2. Incorporate the retriever into a question-answering chain.
const systemPrompt =
  "You are an assistant for question-answering tasks. " +
  "Use the following pieces of retrieved context to answer " +
  "the question. If you don't know the answer, say that you " +
  "don't know. Use three sentences maximum and keep the " +
  "answer concise." +
  "\n\n" +
  "{context}";

const prompt = ChatPromptTemplate.fromMessages([
  ["system", systemPrompt],
  ["human", "{input}"],
]);

const questionAnswerChain = await createStuffDocumentsChain({
  llm,
  prompt,
});

const ragChain = await createRetrievalChain({
  retriever,
  combineDocsChain: questionAnswerChain,
});

const response = await ragChain.invoke({
  input: "What is Task Decomposition?",
});
console.log(response.answer);

const contextualizeQSystemPrompt =
  "Given a chat history and the latest user question " +
  "which might reference context in the chat history, " +
  "formulate a standalone question which can be understood " +
  "without the chat history. Do NOT answer the question, " +
  "just reformulate it if needed and otherwise return it as is.";

const contextualizeQPrompt = ChatPromptTemplate.fromMessages([
  ["system", contextualizeQSystemPrompt],
  new MessagesPlaceholder("chat_history"),
  ["human", "{input}"],
]);

const historyAwareRetriever = await createHistoryAwareRetriever({
  llm,
  retriever,
  rephrasePrompt: contextualizeQPrompt,
});

const qaPrompt = ChatPromptTemplate.fromMessages([
  ["system", systemPrompt],
  new MessagesPlaceholder("chat_history"),
  ["human", "{input}"],
]);

const questionAnswerChain2 = await createStuffDocumentsChain({
  llm,
  prompt: qaPrompt,
});

const ragChain2 = await createRetrievalChain({
  retriever: historyAwareRetriever,
  combineDocsChain: questionAnswerChain2,
});

let chatHistory: BaseMessage[] = [];

const question = "What is Task Decomposition?";
const aiMsg1 = await ragChain2.invoke({
  input: question,
  chat_history: chatHistory,
});
chatHistory = chatHistory.concat([
  new HumanMessage(question),
  new AIMessage(aiMsg1.answer),
]);

const secondQuestion = "What are common ways of doing it?";
const aiMsg2 = await ragChain2.invoke({
  input: secondQuestion,
  chat_history: chatHistory,
});

console.log(aiMsg2.answer);

const demoEphemeralChatMessageHistoryForChain = new ChatMessageHistory();

const conversationalRagChain = new RunnableWithMessageHistory({
  runnable: ragChain2,
  getMessageHistory: (_sessionId) => demoEphemeralChatMessageHistoryForChain,
  inputMessagesKey: "input",
  historyMessagesKey: "chat_history",
  outputMessagesKey: "answer",
});

const result1 = await conversationalRagChain.invoke(
  { input: "What is Task Decomposition?" },
  { configurable: { sessionId: "abc123" } }
);
console.log(result1.answer);

const result2 = await conversationalRagChain.invoke(
  { input: "What are common ways of doing it?" },
  { configurable: { sessionId: "abc123" } }
);
console.log(result2.answer);

// https://js.langchain.com/assets/images/conversational_retrieval_chain-5c7a96abe29e582bc575a0a0d63f86b0.png

const tool = createRetrieverTool(retriever, {
  name: "blog_post_retriever",
  description:
    "Searches and returns excerpts from the Autonomous Agents blog post.",
});
const tools = [tool];

console.log(await tool.invoke({ query: "task decomposition" }));


const agentExecutor = createReactAgent({ llm, tools });

const query = "What is Task Decomposition?";

for await (const s of await agentExecutor.stream({
  messages: [new HumanMessage(query)],
})) {
  console.log(s);
  console.log("----");
}

const memory = new MemorySaver();

const agentExecutorWithMemory = createReactAgent({
  llm,
  tools,
  checkpointSaver: memory,
});

const config = { configurable: { thread_id: "abc123" } };

for await (const s of await agentExecutorWithMemory.stream(
  { messages: [new HumanMessage("Hi! I'm bob")] },
  config
)) {
  console.log(s);
  console.log("----");
}

for await (const s of await agentExecutorWithMemory.stream(
  { messages: [new HumanMessage(query)] },
  config
)) {
  console.log(s);
  console.log("----");
}

const query3 =
  "What according to the blog post are common ways of doing it? redo the search";

for await (const s of await agentExecutorWithMemory.stream(
  { messages: [new HumanMessage(query3)] },
  config
)) {
  console.log(s);
  console.log("----");
}
*/

/* VERSION 1 
import { AzureChatOpenAI,AzureOpenAIEmbeddings } from "@langchain/openai";
import "cheerio";
import { CheerioWebBaseLoader } from "@langchain/community/document_loaders/web/cheerio";
import { RecursiveCharacterTextSplitter } from "langchain/text_splitter";
import { MemoryVectorStore } from "langchain/vectorstores/memory";
import {
  ChatPromptTemplate,
  MessagesPlaceholder,
} from "@langchain/core/prompts";
import { createHistoryAwareRetriever } from "langchain/chains/history_aware_retriever";
import { createStuffDocumentsChain } from "langchain/chains/combine_documents";
import { createRetrievalChain } from "langchain/chains/retrieval";
import { RunnableWithMessageHistory } from "@langchain/core/runnables";
import { ChatMessageHistory } from "langchain/stores/message/in_memory";
import { BaseChatMessageHistory } from "@langchain/core/chat_history";


const AZURE_OPENAI_API_INSTANCE_NAME="<>"
const AZURE_OPENAI_API_DEPLOYMENT_NAME="gpt-4o-mini"
const AZURE_OPENAI_API_KEY="<>"
const AZURE_OPENAI_API_VERSION="2024-08-01-preview"

// Model LLM
const llm2 = new AzureChatOpenAI({
  temperature: 0.9,
  azureOpenAIApiKey: AZURE_OPENAI_API_KEY,
  azureOpenAIApiInstanceName: AZURE_OPENAI_API_INSTANCE_NAME,
  azureOpenAIApiDeploymentName: AZURE_OPENAI_API_DEPLOYMENT_NAME,
  azureOpenAIApiVersion: AZURE_OPENAI_API_VERSION,
});

// Construct retriever
const loader2 = new CheerioWebBaseLoader(
  "https://lilianweng.github.io/posts/2023-06-23-agent/",
  {
    selector: ".post-content, .post-title, .post-header",
  }
);

const EMBED_AZURE_OPENAI_API_INSTANCE_NAME="<>"
const EMBED_AZURE_OPENAI_API_DEPLOYMENT_NAME="text-embedding-3-small"
const EMBED_AZURE_OPENAI_API_KEY="<>"
const EMBED_AZURE_OPENAI_API_VERSION="2023-05-15"

// Embedding Model
const embeddingsModel2 = new AzureOpenAIEmbeddings({
  azureOpenAIApiKey: EMBED_AZURE_OPENAI_API_KEY,
  azureOpenAIApiInstanceName: EMBED_AZURE_OPENAI_API_INSTANCE_NAME,
  azureOpenAIApiEmbeddingsDeploymentName: EMBED_AZURE_OPENAI_API_DEPLOYMENT_NAME,
  azureOpenAIApiVersion: EMBED_AZURE_OPENAI_API_VERSION, 
  maxRetries: 1,
});

const docs2 = await loader2.load();

const textSplitter2 = new RecursiveCharacterTextSplitter({
  chunkSize: 1000,
  chunkOverlap: 200,
});
const splits2 = await textSplitter2.splitDocuments(docs2);
const vectorstore2 = await MemoryVectorStore.fromDocuments(
  splits2,
  embeddingsModel2
);
const retriever2 = vectorstore2.asRetriever();

// Contextualize question
const contextualizeQSystemPrompt2 =
  "Given a chat history and the latest user question " +
  "which might reference context in the chat history, " +
  "formulate a standalone question which can be understood " +
  "without the chat history. Do NOT answer the question, " +
  "just reformulate it if needed and otherwise return it as is.";

const contextualizeQPrompt2 = ChatPromptTemplate.fromMessages([
  ["system", contextualizeQSystemPrompt2],
  new MessagesPlaceholder("chat_history"),
  ["human", "{input}"],
]);

const historyAwareRetriever2 = await createHistoryAwareRetriever({
  llm: llm2,
  retriever: retriever2,
  rephrasePrompt: contextualizeQPrompt2,
});

// Answer question
const systemPrompt2 =
  "You are an assistant for question-answering tasks. " +
  "Use the following pieces of retrieved context to answer " +
  "the question. If you don't know the answer, say that you " +
  "don't know. Use three sentences maximum and keep the " +
  "answer concise." +
  "\n\n" +
  "{context}";

const qaPrompt2 = ChatPromptTemplate.fromMessages([
  ["system", systemPrompt2],
  new MessagesPlaceholder("chat_history"),
  ["human", "{input}"],
]);

const questionAnswerChain3 = await createStuffDocumentsChain({
  llm: llm2,
  prompt: qaPrompt2,
});

const ragChain3 = await createRetrievalChain({
  retriever: historyAwareRetriever2,
  combineDocsChain: questionAnswerChain3,
});

// Statefully manage chat history
const store2: Record<string, BaseChatMessageHistory> = {};

function getSessionHistory2(sessionId: string): BaseChatMessageHistory {
  if (!(sessionId in store2)) {
    store2[sessionId] = new ChatMessageHistory();
  }
  return store2[sessionId];
}

const conversationalRagChain2 = new RunnableWithMessageHistory({
  runnable: ragChain3,
  getMessageHistory: getSessionHistory2,
  inputMessagesKey: "input",
  historyMessagesKey: "chat_history",
  outputMessagesKey: "answer",
});

// Example usage
const query2 = "What is Task Decomposition?";

for await (const s of await conversationalRagChain2.stream(
  { input: query2 },
  { configurable: { sessionId: "unique_session_id" } }
)) {
  console.log(s);
  console.log("----");
}
*/

/* VERSION 2 */
// const LANGCHAIN_TRACING_V2=true
// const LANGCHAIN_API_KEY=YOUR_KEY

// Reduce tracing latency if you are not in a serverless environment
// const LANGCHAIN_CALLBACKS_BACKGROUND=true

import { AzureChatOpenAI,AzureOpenAIEmbeddings } from "@langchain/openai";
import "cheerio";
import { MemorySaver } from "@langchain/langgraph";
import { createReactAgent } from "@langchain/langgraph/prebuilt";
import { CheerioWebBaseLoader } from "@langchain/community/document_loaders/web/cheerio";
import { RecursiveCharacterTextSplitter } from "langchain/text_splitter";
import { MemoryVectorStore } from "langchain/vectorstores/memory";
import { createRetrieverTool } from "langchain/tools/retriever";
import { HumanMessage } from "@langchain/core/messages";


const memory3 = new MemorySaver();

const AZURE_OPENAI_API_INSTANCE_NAME="<>"
const AZURE_OPENAI_API_DEPLOYMENT_NAME="gpt-4o-mini"
const AZURE_OPENAI_API_KEY="<>"
const AZURE_OPENAI_API_VERSION="2024-08-01-preview"

// Model LLM
const llm3 = new AzureChatOpenAI({
  temperature: 0.9,
  azureOpenAIApiKey: AZURE_OPENAI_API_KEY,
  azureOpenAIApiInstanceName: AZURE_OPENAI_API_INSTANCE_NAME,
  azureOpenAIApiDeploymentName: AZURE_OPENAI_API_DEPLOYMENT_NAME,
  azureOpenAIApiVersion: AZURE_OPENAI_API_VERSION,
});

const EMBED_AZURE_OPENAI_API_INSTANCE_NAME="<>"
const EMBED_AZURE_OPENAI_API_DEPLOYMENT_NAME="text-embedding-3-small"
const EMBED_AZURE_OPENAI_API_KEY="<>"
const EMBED_AZURE_OPENAI_API_VERSION="2023-05-15"

// Embedding Model
const embeddingsModel3 = new AzureOpenAIEmbeddings({
  azureOpenAIApiKey: EMBED_AZURE_OPENAI_API_KEY,
  azureOpenAIApiInstanceName: EMBED_AZURE_OPENAI_API_INSTANCE_NAME,
  azureOpenAIApiEmbeddingsDeploymentName: EMBED_AZURE_OPENAI_API_DEPLOYMENT_NAME,
  azureOpenAIApiVersion: EMBED_AZURE_OPENAI_API_VERSION, 
  maxRetries: 1,
});


// Construct retriever
const loader3 = new CheerioWebBaseLoader(
  "https://lilianweng.github.io/posts/2023-06-23-agent/",
  {
    selector: ".post-content, .post-title, .post-header",
  }
);

const docs3 = await loader3.load();

const textSplitter3 = new RecursiveCharacterTextSplitter({
  chunkSize: 1000,
  chunkOverlap: 200,
});
const splits3 = await textSplitter3.splitDocuments(docs3);
const vectorstore3 = await MemoryVectorStore.fromDocuments(
  splits3,
  embeddingsModel3
);
const retriever3 = vectorstore3.asRetriever();

// Build retriever tool
const tool3 = createRetrieverTool(retriever3, {
  name: "blog_post_retriever",
  description:
    "Searches and returns excerpts from the Autonomous Agents blog post.",
});
const tools3 = [tool3];

const agentExecutor3 = createReactAgent({
  llm: llm3,
  tools: tools3,
  checkpointSaver: memory3,
});

console.log(agentExecutor3);

//const query = "What is Task Decomposition?";
/*
for await (const s of await agentExecutor3.stream({
  messages: [new HumanMessage(query)],
})) {
  console.log(s);
  console.log("----");
}
*/