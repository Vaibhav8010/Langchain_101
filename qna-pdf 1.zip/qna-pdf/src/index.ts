// https://js.langchain.com/docs/tutorials/pdf_qa/


import "pdf-parse"; // Peer dep
import { PDFLoader } from "@langchain/community/document_loaders/fs/pdf";
import { AzureChatOpenAI, AzureOpenAIEmbeddings } from "@langchain/openai";
import { MemoryVectorStore } from "langchain/vectorstores/memory";
import { RecursiveCharacterTextSplitter } from "@langchain/textsplitters";
import { createRetrievalChain } from "langchain/chains/retrieval";
import { createStuffDocumentsChain } from "langchain/chains/combine_documents";
import { ChatPromptTemplate } from "@langchain/core/prompts";

const loader = new PDFLoader("05-versions-space.pdf");

const docs = await loader.load();

// console.log(docs.length);

//console.log(docs[0].pageContent.slice(0, 100));
//console.log(docs[0].metadata);


// "Nike's revenue in fiscal 2023 was $51.2 billion. This represented a 10% increase compared to fiscal 2022 on a reported basis."

const AZURE_OPENAI_API_INSTANCE_NAME="<>"
const AZURE_OPENAI_API_KEY="<>"
const AZURE_OPENAI_API_DEPLOYMENT_NAME="gpt-4o-mini"
const AZURE_OPENAI_API_VERSION="2024-08-01-preview"
const EMB_AZURE_OPENAI_API_DEPLOYMENT_NAME="text-embedding-3-small"
const EMB_AZURE_OPENAI_API_VERSION="2023-05-15"



// Model LLM
const llm = new AzureChatOpenAI({
  temperature: 0.9,
  azureOpenAIApiKey: AZURE_OPENAI_API_KEY,
  azureOpenAIApiInstanceName: AZURE_OPENAI_API_INSTANCE_NAME,
  azureOpenAIApiDeploymentName: AZURE_OPENAI_API_DEPLOYMENT_NAME,
  azureOpenAIApiVersion: AZURE_OPENAI_API_VERSION,
});


const embeddings = new AzureOpenAIEmbeddings({
  azureOpenAIApiKey: AZURE_OPENAI_API_KEY,
  azureOpenAIApiInstanceName: AZURE_OPENAI_API_INSTANCE_NAME,
  azureOpenAIApiEmbeddingsDeploymentName: EMB_AZURE_OPENAI_API_DEPLOYMENT_NAME,
  azureOpenAIApiVersion: EMB_AZURE_OPENAI_API_VERSION, 
  maxRetries: 1,
});


const textSplitter = new RecursiveCharacterTextSplitter({
    chunkSize: 1000,
    chunkOverlap: 200,
  });
  
  const splits = await textSplitter.splitDocuments(docs);
  
  const vectorstore = await MemoryVectorStore.fromDocuments(
    splits,
    embeddings    
  );
  
  const retriever = vectorstore.asRetriever();

  const systemTemplate = [
    `You are an assistant for question-answering tasks. `,
    `Use the following pieces of retrieved context to answer `,
    `the question. If you don't know the answer, say that you `,
    `don't know. Use three sentences maximum and keep the `,
    `answer concise.`,
    `\n\n`,
    `{context}`,
  ].join("");
  
  const prompt = ChatPromptTemplate.fromMessages([
    ["system", systemTemplate],
    ["human", "{input}"],
  ]);
  
  const questionAnswerChain = await createStuffDocumentsChain({
    llm: llm,
    prompt,
  });
  const ragChain = await createRetrievalChain({
    retriever,
    combineDocsChain: questionAnswerChain,
  });
  
  const results = await ragChain.invoke({
    input: "What was Nike's revenue in 2023?",
  });
  
  console.log(results);