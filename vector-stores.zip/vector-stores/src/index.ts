// https://js.langchain.com/docs/concepts/vectorstores/
/*
Vector stores are specialized data stores that enable indexing and retrieving information based on vector representations.
These vectors, called embeddings, capture the semantic meaning of data that has been embedded.
Vector stores are frequently used to search over unstructured data, such as text, images, and audio, to retrieve relevant information based on semantic similarity rather than exact keyword matches.
*/
// https://js.langchain.com/assets/images/vectorstores-2540b4bc355b966c99b0f02cfdddb273.png

import { MemoryVectorStore } from "langchain/vectorstores/memory";
import { AzureOpenAIEmbeddings } from "@langchain/openai";
import { Document } from "@langchain/core/documents";

const AZURE_OPENAI_API_INSTANCE_NAME="<>"
const AZURE_OPENAI_API_DEPLOYMENT_NAME="text-embedding-3-small"
const AZURE_OPENAI_API_KEY="<>"
const AZURE_OPENAI_API_VERSION="2023-05-15"

const SomeEmbeddingModel = new AzureOpenAIEmbeddings({
  azureOpenAIApiKey: AZURE_OPENAI_API_KEY,
  azureOpenAIApiInstanceName: AZURE_OPENAI_API_INSTANCE_NAME,
  azureOpenAIApiEmbeddingsDeploymentName: AZURE_OPENAI_API_DEPLOYMENT_NAME,
  azureOpenAIApiVersion: AZURE_OPENAI_API_VERSION, 
  maxRetries: 1,
});


// Initialize with an embedding model
const vectorStore = new MemoryVectorStore(SomeEmbeddingModel);

const document1 = new Document({
    pageContent: "I had chocalate chip pancakes and scrambled eggs for breakfast this morning.",
    metadata: { source: "tweet" },
  })

const document2 = new Document({
    pageContent: "The weather forecast for tomorrow is cloudy and overcast, with a high of 62 degrees.",
    metadata: { source: "news" },
})

const documents = [document1, document2]

await vectorStore.addDocuments(documents);

const query = "pan cakes";

const docs = await vectorStore.similaritySearch(query,1);

console.log(docs);

/*
await vectorstore.similaritySearch(
  "LangChain provides abstractions to make working with LLMs easy",
  2,
  {
    // The arguments of this field are provider specific.
    filter: { source: "tweet" },
  }
);
*/