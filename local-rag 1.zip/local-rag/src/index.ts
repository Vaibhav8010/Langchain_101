// https://js.langchain.com/docs/tutorials/local_rag

import "cheerio";
import { RecursiveCharacterTextSplitter } from "langchain/text_splitter";
import { CheerioWebBaseLoader } from "@langchain/community/document_loaders/web/cheerio";
import { ChatOllama, OllamaEmbeddings } from "@langchain/ollama";
import { MemoryVectorStore } from "langchain/vectorstores/memory";

import { 
    RunnablePassthrough, 
    RunnableSequence,
    } from "@langchain/core/runnables";
  import { formatDocumentsAsString } from "langchain/util/document";

import { StringOutputParser } from "@langchain/core/output_parsers";
import { PromptTemplate } from "@langchain/core/prompts";
import { createStuffDocumentsChain } from "langchain/chains/combine_documents";

import { pull } from "langchain/hub";
import { ChatPromptTemplate } from "@langchain/core/prompts";


// Doc Loader
const loader = new CheerioWebBaseLoader(
    "https://lilianweng.github.io/posts/2023-06-23-agent/"
  );

  const doc = await loader.load();
  
// Spliter  
  const textSplitter = new RecursiveCharacterTextSplitter({
    chunkSize: 500,
    chunkOverlap: 0,
  });
  const allSplits = await textSplitter.splitDocuments(doc);
  
//  console.log(allSplits.length);

// Embedding Model
const embeddings = new OllamaEmbeddings(
    {
    baseUrl: "http://localhost:11434",
    model: "nomic-embed-text",
    }
);

// Vector Store
const vectorStore = await MemoryVectorStore.fromDocuments(
  allSplits,
  embeddings
);

// const question = "What are the approaches to Task Decomposition?";
// const docs = await vectorStore.similaritySearch(question);
// console.log(docs.length);

// LLM
const ollamaLlm = new ChatOllama({
    baseUrl: "http://localhost:11434", // Default value
    model: "llama2", // Default value
  });

  /*
  const response = await ollamaLlm.invoke(
    "Hi I am Bob"
    //"Simulate a rap battle between Stephen Colbert and John Oliver"
  );
  console.log(response.content);  
*/

/*
  const prompt = PromptTemplate.fromTemplate(
    "Summarize the main themes in these retrieved docs: {context}"
  );
  
  const chain = await createStuffDocumentsChain({
    llm: ollamaLlm,
    outputParser: new StringOutputParser(),
    prompt,
  });

  const question = "What are the approaches to Task Decomposition?";
  const docs = await vectorStore.similaritySearch(question);
  
  const res = await chain.invoke({
    context: docs, question
  });

  console.log(res);
*/


    const question = "What are the approaches to Task Decomposition?";
    const ragPrompt = await pull<ChatPromptTemplate>("rlm/rag-prompt");

  /*

  const chainSD = await createStuffDocumentsChain({
    llm: ollamaLlm,
    outputParser: new StringOutputParser(),
    prompt: ragPrompt,
    });

    
    console.log(
        ragPrompt.promptMessages.map((msg) => msg.prompt.template).join("\n")
      );
*/
// Retriever
const retriever = vectorStore.asRetriever();

// Q&A Chain
const qaChain = RunnableSequence.from([
  {
    context: (input: { question: string }, callbacks) => {
      const retrieverAndFormatter = retriever.pipe(formatDocumentsAsString);
      return retrieverAndFormatter.invoke(input.question, callbacks);
    },
    question: new RunnablePassthrough(),
  },
  ragPrompt,
  ollamaLlm,
  new StringOutputParser(),
]);

// Output
const result = await qaChain.invoke({ question });

console.log(result);

